#!/bin/bash
awk -F',' '{s+=$(NF)} END{print s}' power_levels.txt 
