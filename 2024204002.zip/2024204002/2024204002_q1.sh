#!/bin/bash
grep -i "POST" access.log | grep "404"
