1. for 2024204002_q1.sh, I used grep command to search the "POST" and "404" together.
I used "|" to denote AND for implementing POST and 404 together
2. for 2024204002_q2.sh, I used awk command. I used -F',' to specify comma as a delimiter for separation.
Then I added the last entry of the row to the sum using $NF and then printed the sum
